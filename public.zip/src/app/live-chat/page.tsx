import LiveChat from "@/components/Message";

const page = () => {
  return <LiveChat />;
};

export default page;
